import {BrowserModule} from '@angular/platform-browser';
import {NgModule, NO_ERRORS_SCHEMA} from '@angular/core';

import {AppComponent} from './app.component';

import { HttpClientModule } from '@angular/common/http';

import {MDBBootstrapModule} from 'angular-bootstrap-md';
import { HeaderComponent } from './header/header.component';
import { ListSelectorComponent } from './list-selector/list-selector.component';
import { ListSmallComponent } from './list-small/list-small.component';
import { ListLargeComponent } from './list-large/list-large.component';
import { ListDetailsComponent } from './list-details/list-details.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    ListSelectorComponent,
    ListSmallComponent,
    ListLargeComponent,
    ListDetailsComponent
  ],
  imports: [
    BrowserModule,
    MDBBootstrapModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent],
  schemas: [NO_ERRORS_SCHEMA]
})
export class AppModule {
}
