import {ProductItemInterface} from './product-item-interface';

export interface ProductResponse {
  data: ProductItemInterface[];
}
