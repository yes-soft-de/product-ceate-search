import {Injectable} from '@angular/core';
import {HttpClient, HttpErrorResponse, HttpHeaders} from '@angular/common/http';
import {catchError, map} from 'rxjs/operators';
import {ProductResponse} from './product-response';
import {ProductItem} from './product-item';
import {Observable, throwError} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {
  configUrl = 'assets/sample_data.json';
  serverUrl = 'https://webhook.site/2a598979-798e-4919-aa1b-0cf4079eef12';
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(private http: HttpClient) {
  }

  getProductList() {
    return this.http.get<ProductResponse>(`${this.configUrl}`).pipe(
      map((response: ProductResponse) => {
        return response.data;
      })
    );
  }

  getProductById(id: number) {
    return this.http.get<ProductResponse>(`${this.configUrl}/${id}`).pipe(
      map((response: ProductResponse) => {
        return response.data;
      })
    );
  }

  postProduct(product: ProductItem) {

    /** POST: add a new hero to the database */
    return this.http.post<ProductItem>(this.serverUrl, JSON.stringify(product), this.httpOptions)
      .subscribe(
          data => {
            console.log('POST Request is successful ', data);
          }, error1 => {
            console.log('Error', error1);
          }
      );
    // return this.http.post(this.serverUrl, JSON.stringify(product)).subscribe(
    //   data => {
    //     console.log('POST Request is successful ', data);
    //   }, error1 => {
    //     console.log('Error', error1);
    //   }
    // );
  }
}


