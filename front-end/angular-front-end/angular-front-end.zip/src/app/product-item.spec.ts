import { ProductItem } from './product-item';

describe('ProductItem', () => {
  it('should create an instance', () => {
    expect(new ProductItem()).toBeTruthy();
  });
});
