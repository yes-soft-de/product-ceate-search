import {ProductItem} from './product-item';

export interface ProductResponse {
  data: ProductItem[];
}
