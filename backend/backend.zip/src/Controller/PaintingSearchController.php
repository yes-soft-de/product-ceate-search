<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;

use Elasticsearch\ClientBuilder;

class PaintingSearchController extends AbstractController
{
    /**
     * @Route("/painting/search", name="painting_search")
     */
    public function index(Request $request)
    {
        if (0 === strpos($request->headers->get('Content-Type'), 'application/json')) {
            $client = ClientBuilder::create()->build();

            $data = json_decode($request->getContent(), true);
            // TODO Iterate Through $data and add matches
            // Now that the request is here, we redirect to Elastic Search 
            $params = [
                'index' => 'yes_topic',
                'body' => [
                    'query' => [
                        'match' => [
                            'message' => 'Hello'
                        ]
                    ]
                ]
            ];
            $response = $client->search($params);
            return $this->json([
                'data' => $response
            ]);
        }
        return $this->json([
            'message' => 'Welcome to your new controller!',
            'path' => 'src/Controller/PaintingSearchController.php'
        ]);
    }
}
