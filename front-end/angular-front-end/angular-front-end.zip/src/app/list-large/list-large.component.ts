import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-large',
  templateUrl: './list-large.component.html',
  styleUrls: ['./list-large.component.scss']
})
export class ListLargeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
