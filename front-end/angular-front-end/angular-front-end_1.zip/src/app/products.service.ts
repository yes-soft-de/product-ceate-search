import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {map} from 'rxjs/operators';
import {ProductResponse} from './product-response';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {
  configUrl = 'assets/sample_data.json';

  constructor(private http: HttpClient) { }

  getProductList() {
    return this.http.get<ProductResponse>(`${this.configUrl}`).pipe(
      map((response: ProductResponse) => {
        return response.data;
      })
    );
  }
}


